package com.example.pricecheck

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QueryParserTest {
    @Test fun fat() {
        val q = QueryParser.parse("Масло 82 процента жирности")!!
        assertEquals(82.0, q.fatPercent!!, 0.0)
        assertEquals(listOf("масло"), q.keywords)
    }
    @Test fun noYeast() {
        val q = QueryParser.parse("хлеб без дрожжей")!!
        assertEquals(setOf("no_yeast"), q.tags)
        assertEquals(listOf("хлеб"), q.keywords)
    }
    @Test fun ownJuice() {
        val q = QueryParser.parse("Консерва тунец в своем соку")!!
        assertEquals(setOf("own_juice"), q.tags)
        assertEquals(listOf("консерва", "тунец"), q.keywords)
    }
    @Test fun cheapestWins() {
        val catalog = listOf(
            Product("Сильпо", "Молоко", 41.9, 2.5),
            Product("АТБ", "Молоко", 36.9, 2.5),
            Product("АТБ", "Молоко", 38.5, 3.2),
        )
        val r = PriceCalculator(catalog).calculate(listOf(QueryParser.parse("молоко 2.5%")!!))
        assertEquals("АТБ", r.items[0].best!!.store)
    }
    @Test fun brandNameDoesNotMatchOtherProduct() {
        val kefir = Product("АТБ", "Кефір 0,87 кг Молокія 2,5%", 60.0, 2.5, weightG = 870.0)
        assertFalse(kefir.matches(QueryParser.parse("молоко 2.5%")!!))
    }
    @Test fun ukrainianNamesMatchRussianQuery() {
        val bread = Product("АТБ", "Хліб Київхліб без дріжджів 300 г", 25.0, tags = setOf("no_yeast"), weightG = 300.0)
        val tuna = Product("АТБ", "Тунець 185 г Seven у власному соку з/б", 89.9, tags = setOf("own_juice"), weightG = 185.0)
        assertTrue(bread.matches(QueryParser.parse("хлеб без дрожжей")!!))
        assertTrue(tuna.matches(QueryParser.parse("консерва тунец в своем соку")!!))
    }
    @Test fun comparesByPricePerKg() {
        val small = Product("АТБ", "Молоко 450 г Щоденний збір 2,5%", 23.5, 2.5, weightG = 450.0)  // 52.2/кг
        val big = Product("АТБ", "Молоко 2 кг Щоденний збір 2,5%", 100.0, 2.5, weightG = 2000.0)   // 50/кг
        val r = PriceCalculator(listOf(small, big)).calculate(listOf(QueryParser.parse("молоко 2.5%")!!))
        assertEquals(big, r.items[0].best)
    }
}
