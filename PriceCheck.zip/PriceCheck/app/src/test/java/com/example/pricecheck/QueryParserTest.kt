package com.example.pricecheck

import org.junit.Assert.assertEquals
import org.junit.Test

class QueryParserTest {
    @Test fun fat() {
        val q = QueryParser.parse("Масло 82 процента жирности")!!
        assertEquals(82.0, q.fatPercent!!, 0.0)
        assertEquals(listOf("масло"), q.keywords)
    }
    @Test fun noYeast() {
        val q = QueryParser.parse("хлеб без дрожжей")!!
        assertEquals(setOf("no_yeast"), q.tags)
        assertEquals(listOf("хлеб"), q.keywords)
    }
    @Test fun ownJuice() {
        val q = QueryParser.parse("Консерва тунец в своем соку")!!
        assertEquals(setOf("own_juice"), q.tags)
        assertEquals(listOf("консерва", "тунец"), q.keywords)
    }
    @Test fun cheapestWins() {
        val catalog = FakeCatalog.items
        val r = PriceCalculator(catalog).calculate(listOf(QueryParser.parse("молоко 2.5%")!!))
        assertEquals("АТБ", r.items[0].best!!.store)
    }
}

private object FakeCatalog {
    val items = listOf(
        Product("Сильпо", "Молоко", 41.9, 2.5),
        Product("АТБ", "Молоко", 36.9, 2.5),
        Product("АТБ", "Молоко", 38.5, 3.2),
    )
}
