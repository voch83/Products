package com.example.pricecheck

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: PriceRepository = FakePriceRepository(),
) : ViewModel() {

    var input by mutableStateOf("Хлеб без дрожжей\nМасло 82 процента жирности\nМолоко 2.5 процента жирности\nКонсерва тунец в своем соку")
    var result by mutableStateOf<CalcResult?>(null)
        private set
    var loading by mutableStateOf(false)
        private set

    fun calculate() {
        viewModelScope.launch {
            loading = true
            val catalog = repository.getProducts()
            val queries = input.lines().mapNotNull(QueryParser::parse)
            result = PriceCalculator(catalog).calculate(queries)
            loading = false
        }
    }
}
