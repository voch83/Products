package com.example.pricecheck

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var input by mutableStateOf("Хлеб без дрожжей\nМасло 82 процента жирности\nМолоко 2.5 процента жирности\nКонсерва тунец в своем соку")
    var priceUrl by mutableStateOf(prefs.getString("price_url", "") ?: "")
        private set
    var result by mutableStateOf<CalcResult?>(null)
        private set
    var source by mutableStateOf("")
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var loading by mutableStateOf(false)
        private set

    fun savePriceUrl(value: String) {
        priceUrl = value
        prefs.edit().putString("price_url", value.trim()).apply()
    }

    fun calculate() {
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val url = priceUrl.trim()
                val catalog: List<Product>
                if (url.isEmpty()) {
                    catalog = FakePriceRepository().getProducts()
                    source = "тестовые цены"
                } else {
                    val repo = RemotePriceRepository(url)
                    catalog = repo.getProducts()
                    source = "АТБ, обновлено ${repo.updated} (${catalog.size} товаров)"
                }
                val queries = input.lines().mapNotNull(QueryParser::parse)
                result = PriceCalculator(catalog).calculate(queries)
            } catch (e: Exception) {
                error = "Не удалось загрузить цены: ${e.message}"
            } finally {
                loading = false
            }
        }
    }
}
