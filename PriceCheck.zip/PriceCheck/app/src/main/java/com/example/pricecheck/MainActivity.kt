package com.example.pricecheck

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { ShoppingScreen() } } }
    }
}

private fun money(v: Double) = "%.2f грн".format(v)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingScreen(vm: MainViewModel = viewModel()) {
    Scaffold(topBar = { TopAppBar(title = { Text("Список покупок") }) }) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                OutlinedTextField(
                    value = vm.input,
                    onValueChange = { vm.input = it },
                    label = { Text("Один товар на строку") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 5,
                )
            }
            item {
                OutlinedTextField(
                    value = vm.priceUrl,
                    onValueChange = vm::savePriceUrl,
                    label = { Text("Адрес prices.json (пусто = тестовые цены)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Button(onClick = vm::calculate, enabled = !vm.loading) { Text("Рассчитать") }
            }

            vm.error?.let { e ->
                item { Text(e, color = MaterialTheme.colorScheme.error) }
            }
            val r = vm.result
            if (r != null) {
                item { Text("Источник: ${vm.source}", style = MaterialTheme.typography.bodySmall) }
                items(r.items) { item ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(item.query.raw, fontWeight = FontWeight.Bold)
                            val p = item.best
                            if (p == null) {
                                Text("Ничего подходящего не найдено")
                            } else {
                                Text("${p.store}: ${p.name}")
                                val unit = if (p.weightG != null) " · ${"%.0f".format(p.unitPrice)} грн/кг" else ""
                                Text(money(p.price) + unit)
                            }
                        }
                    }
                }
                item {
                    Text("Итого (самое дешёвое везде): ${money(r.splitTotal)}", fontWeight = FontWeight.Bold)
                }
                item { Text("По магазинам:", style = MaterialTheme.typography.titleMedium) }
                items(r.storeTotals) { s ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(s.store + if (s.missing.isNotEmpty()) " (нет: ${s.missing.size})" else "")
                        Text(money(s.total))
                    }
                }
            }
        }
    }
}
