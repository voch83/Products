package com.example.pricecheck

interface PriceRepository {
    suspend fun getProducts(): List<Product>
}

/**
 * ТЕСТОВЫЕ данные (цены выдуманы). Позже заменяется на RemotePriceRepository,
 * который берёт цены с вашего бэкенда.
 */
class FakePriceRepository : PriceRepository {
    override suspend fun getProducts() = listOf(
        // Сильпо
        Product("Сильпо", "Хлеб бездрожжевой зерновой", 42.90, tags = setOf("no_yeast")),
        Product("Сильпо", "Хлеб пшеничный нарезной", 31.50),
        Product("Сильпо", "Масло сладкосливочное", 109.00, 82.5),
        Product("Сильпо", "Масло сладкосливочное", 95.00, 72.5),
        Product("Сильпо", "Молоко", 41.90, 2.5),
        Product("Сильпо", "Тунец консервированный в собственном соку", 89.90, tags = setOf("own_juice")),
        // АТБ
        Product("АТБ", "Хлеб без дрожжей ржаной", 39.50, tags = setOf("no_yeast")),
        Product("АТБ", "Масло крестьянское", 99.90, 72.5),
        Product("АТБ", "Масло традиционное", 118.00, 82.0),
        Product("АТБ", "Молоко", 36.90, 2.5),
        Product("АТБ", "Молоко", 38.50, 3.2),
        Product("АТБ", "Тунец консервированный в масле", 74.00),
        // Варус
        Product("Варус", "Хлеб гречневый без дрожжей", 47.00, tags = setOf("no_yeast")),
        Product("Варус", "Масло сладкосливочное", 104.50, 82.5),
        Product("Варус", "Молоко", 39.90, 2.5),
        Product("Варус", "Тунец консервированный в собственном соку", 84.00, tags = setOf("own_juice")),
    )
}
