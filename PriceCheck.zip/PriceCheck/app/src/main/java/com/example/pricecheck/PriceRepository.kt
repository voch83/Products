package com.example.pricecheck

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

interface PriceRepository {
    suspend fun getProducts(): List<Product>
}

/** Цены с бэкенда: prices.json, который раз в день обновляет GitHub Actions. */
class RemotePriceRepository(private val url: String) : PriceRepository {
    var updated: String = ""
        private set

    override suspend fun getProducts(): List<Product> = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15_000
        conn.readTimeout = 30_000
        try {
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(text)
            updated = root.optString("updated")
            val defaultStore = root.optString("store", "АТБ")
            val arr = root.getJSONArray("products")
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                val tags = mutableSetOf<String>()
                o.optJSONArray("tags")?.let { ta ->
                    for (j in 0 until ta.length()) tags += ta.getString(j)
                }
                Product(
                    store = o.optString("store", defaultStore),
                    name = o.getString("name"),
                    price = o.getDouble("price"),
                    fatPercent = if (o.has("fat") && !o.isNull("fat")) o.getDouble("fat") else null,
                    tags = tags,
                    weightG = if (o.has("weight_g") && !o.isNull("weight_g")) o.getDouble("weight_g") else null,
                )
            }
        } finally {
            conn.disconnect()
        }
    }
}

/** ТЕСТОВЫЕ данные (цены выдуманы). Используются, пока не указан адрес prices.json. */
class FakePriceRepository : PriceRepository {
    override suspend fun getProducts() = listOf(
        Product("Сильпо", "Хлеб бездрожжевой зерновой", 42.90, tags = setOf("no_yeast")),
        Product("Сильпо", "Хлеб пшеничный нарезной", 31.50),
        Product("Сильпо", "Масло сладкосливочное", 109.00, 82.5),
        Product("Сильпо", "Масло сладкосливочное", 95.00, 72.5),
        Product("Сильпо", "Молоко", 41.90, 2.5),
        Product("Сильпо", "Тунец консервированный в собственном соку", 89.90, tags = setOf("own_juice")),
        Product("АТБ", "Хлеб без дрожжей ржаной", 39.50, tags = setOf("no_yeast")),
        Product("АТБ", "Масло крестьянское", 99.90, 72.5),
        Product("АТБ", "Масло традиционное", 118.00, 82.0),
        Product("АТБ", "Молоко", 36.90, 2.5),
        Product("АТБ", "Молоко", 38.50, 3.2),
        Product("АТБ", "Тунец консервированный в масле", 74.00),
        Product("Варус", "Хлеб гречневый без дрожжей", 47.00, tags = setOf("no_yeast")),
        Product("Варус", "Масло сладкосливочное", 104.50, 82.5),
        Product("Варус", "Молоко", 39.90, 2.5),
        Product("Варус", "Тунец консервированный в собственном соку", 84.00, tags = setOf("own_juice")),
    )
}
