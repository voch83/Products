package com.example.pricecheck

/** Товар из каталога магазина. */
data class Product(
    val store: String,
    val name: String,
    val price: Double,
    val fatPercent: Double? = null,
    val tags: Set<String> = emptySet(), // "no_yeast", "own_juice", ...
    val weightG: Double? = null,        // вес/объём упаковки в граммах (или мл)
) {
    /** Цена за кг (или л). Если вес неизвестен, сравниваем по цене упаковки. */
    val unitPrice: Double
        get() = if (weightG != null && weightG > 0) price / weightG * 1000 else price
}

/** Разобранная строка списка покупок. */
data class Query(
    val raw: String,
    val keywords: List<String>,
    val fatPercent: Double?,
    val tags: Set<String>,
)

data class ItemResult(val query: Query, val best: Product?)

data class StoreTotal(val store: String, val total: Double, val missing: List<String>)

data class CalcResult(
    val items: List<ItemResult>,
    val splitTotal: Double,
    val storeTotals: List<StoreTotal>,
)
