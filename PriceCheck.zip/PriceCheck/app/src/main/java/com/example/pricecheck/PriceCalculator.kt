package com.example.pricecheck

private val wordSplitter = Regex("""[^\p{L}\p{N}]+""")

// Русский -> украинский для слов, которые иначе не совпадут
private val synonyms = mapOf("хлеб" to "хлиб", "хлеба" to "хлиб")

/** Приводит русские и украинские буквы к общему виду. */
private fun norm(word: String): String {
    val s = word.lowercase()
        .replace('ё', 'е').replace('ы', 'и').replace('э', 'е')
        .replace('ї', 'и').replace('і', 'и').replace('є', 'е').replace('ґ', 'г')
    return synonyms[s] ?: s
}

/** Грубый "стемминг": первые 5 букв. */
private fun stem(word: String) = norm(word).take(5)

private val genericStems = listOf("консерва", "консервы", "консерви", "продукт").map(::stem).toSet()

/**
 * Товар подходит, если:
 *  - его ПЕРВОЕ слово совпадает с одним из слов запроса (отсеивает "Кефір ... Молокія"
 *    для запроса "молоко"),
 *  - все значимые слова запроса есть в названии,
 *  - совпадают жирность и теги.
 */
fun Product.matches(q: Query): Boolean {
    val words = name.lowercase().split(wordSplitter).filter { it.isNotBlank() }
    if (words.isEmpty() || q.keywords.isEmpty()) return false
    val nameStems = words.map(::stem).toSet()
    val all = q.keywords.map(::stem)
    val required = all.filter { it !in genericStems }.ifEmpty { all }
    return stem(words.first()) in all &&
        required.all { it in nameStems } &&
        tags.containsAll(q.tags) &&
        (q.fatPercent == null || fatPercent == q.fatPercent)
}

class PriceCalculator(private val catalog: List<Product>) {

    private fun cheapest(candidates: List<Product>) = candidates.minByOrNull { it.unitPrice }

    fun calculate(queries: List<Query>): CalcResult {
        val items = queries.map { q ->
            ItemResult(q, cheapest(catalog.filter { it.matches(q) }))
        }
        val splitTotal = items.sumOf { it.best?.price ?: 0.0 }

        val storeTotals = catalog.map { it.store }.distinct().map { store ->
            var total = 0.0
            val missing = mutableListOf<String>()
            for (q in queries) {
                val p = cheapest(catalog.filter { it.store == store && it.matches(q) })
                if (p == null) missing += q.raw else total += p.price
            }
            StoreTotal(store, total, missing)
        }.sortedWith(compareBy({ it.missing.size }, { it.total }))

        return CalcResult(items, splitTotal, storeTotals)
    }
}
