package com.example.pricecheck

private val wordSplitter = Regex("""[^\p{L}\p{N}]+""")

/** Грубый "стемминг": первые 5 букв. Заменим на нормальное сопоставление позже. */
private fun stem(word: String) = word.take(5)

fun Product.matches(q: Query): Boolean {
    val nameStems = name.lowercase().split(wordSplitter).map(::stem).toSet()
    return q.keywords.all { stem(it) in nameStems } &&
        tags.containsAll(q.tags) &&
        (q.fatPercent == null || fatPercent == q.fatPercent)
}

class PriceCalculator(private val catalog: List<Product>) {

    fun calculate(queries: List<Query>): CalcResult {
        val items = queries.map { q ->
            ItemResult(q, catalog.filter { it.matches(q) }.minByOrNull { it.price })
        }
        val splitTotal = items.sumOf { it.best?.price ?: 0.0 }

        val storeTotals = catalog.map { it.store }.distinct().map { store ->
            var total = 0.0
            val missing = mutableListOf<String>()
            for (q in queries) {
                val p = catalog.filter { it.store == store && it.matches(q) }.minByOrNull { it.price }
                if (p == null) missing += q.raw else total += p.price
            }
            StoreTotal(store, total, missing)
        }.sortedWith(compareBy({ it.missing.size }, { it.total }))

        return CalcResult(items, splitTotal, storeTotals)
    }
}
