package com.example.pricecheck

/**
 * Превращает строку вида "Масло 82 процента жирности" в Query:
 * ключевые слова + жирность + теги (без дрожжей, в собственном соку).
 * Правила простые, расширяются добавлением строк в tagRules.
 */
object QueryParser {
    private val fatRegex =
        Regex("""(\d+(?:[.,]\d+)?)\s*(?:%|процент\p{L}*)(?:\s*жирност\p{L}*)?""")

    private val tagRules = listOf(
        Regex("""без\s+(?:дрожжей|дріжджів)""") to "no_yeast",
        Regex("""в\s+(?:своем|собственном|своєму|власному)\s+(?:соку|соке)""") to "own_juice",
    )

    private val stopWords = setOf("в", "на", "и", "с", "жирности", "жирность")
    private val splitter = Regex("""[^\p{L}\p{N}]+""")

    fun parse(line: String): Query? {
        var text = line.lowercase().trim()
        if (text.isEmpty()) return null

        var fat: Double? = null
        val fatMatch = fatRegex.find(text)
        if (fatMatch != null) {
            fat = fatMatch.groupValues[1].replace(',', '.').toDouble()
            text = text.replace(fatMatch.value, " ")
        }

        val tags = mutableSetOf<String>()
        for ((regex, tag) in tagRules) {
            if (regex.containsMatchIn(text)) {
                tags += tag
                text = regex.replace(text, " ")
            }
        }

        val keywords = text.split(splitter).filter { it.isNotBlank() && it !in stopWords }
        return Query(line.trim(), keywords, fat, tags)
    }
}
